package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.UserAddress;

public interface UserAddressMapper extends MyMapper<UserAddress> {
}