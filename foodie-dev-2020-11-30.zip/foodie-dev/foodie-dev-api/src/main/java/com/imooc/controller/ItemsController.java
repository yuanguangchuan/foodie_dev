package com.imooc.controller;

import com.imooc.enums.YesOrNo;
import com.imooc.pojo.*;
import com.imooc.pojo.vo.*;
import com.imooc.service.CarouselService;
import com.imooc.service.CategoryService;
import com.imooc.service.ItemService;
import com.imooc.utils.IMOOCJSONResult;
import com.imooc.utils.PagedGridResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tk.mybatis.mapper.util.StringUtil;

import java.util.List;

@Api(value = "商品接口",tags = {"商品信息展示的相关接口"})
@RestController
@RequestMapping("items")
public class ItemsController extends BaseController{

    @Autowired
    ItemService itemService;


    @ApiOperation(value = "查询商品详情", notes = "查询商品详情", httpMethod = "GET")
    @GetMapping("/info/{itemId}")
    public IMOOCJSONResult info(
            @ApiParam(name = "itemId",value = "商品id(cake-1002)",required = true)
            @PathVariable String itemId){
        if(StringUtils.isBlank(itemId)) {
            return IMOOCJSONResult.errorMsg(null);
        }
        Items item = itemService.queryItemById(itemId);
        List<ItemsImg> itemImgList = itemService.queryItemImgList(itemId);
        List<ItemsSpec> itemSpecList = itemService.queryItemSpecList(itemId);
        ItemsParam itemParams = itemService.queryItemParam(itemId);

        ItemInfoVO itemInfoVO = new ItemInfoVO();
        itemInfoVO.setItem(item);
        itemInfoVO.setItemImgList(itemImgList);
        itemInfoVO.setItemParams(itemParams);
        itemInfoVO.setItemSpecList(itemSpecList);

        return IMOOCJSONResult.ok(itemInfoVO);
    }
    @ApiOperation(value = "查询商品评价等级", notes = "查询商品评价等级", httpMethod = "GET")
    @GetMapping("/commentLevel")
    public IMOOCJSONResult commentLevel(
            @ApiParam(name = "itemId",value = "商品id(cake-1002)",required = true)
            @RequestParam String itemId){
        if(StringUtils.isBlank(itemId)) {
            return IMOOCJSONResult.errorMsg(null);
        }
        CommentLevelCountsVO countsVO = itemService.queryCommentCounts(itemId);

        return IMOOCJSONResult.ok(countsVO);
    }

    @ApiOperation(value = "查询商品评论", notes = "查询商品评论", httpMethod = "GET")
    @GetMapping("/comments")
    public IMOOCJSONResult comments(
            @ApiParam(name = "itemId",value = "商品id(cake-1002)",required = true)
            @RequestParam String itemId,
            @ApiParam(name = "level",value = "评论等级",required = false)
            @RequestParam Integer level,
            @ApiParam(name = "page",value = "查询下一页的第几页",required = false)
            @RequestParam Integer page,
            @ApiParam(name = "pageSize",value = "分页的每一页显示的条数",required = false)
            @RequestParam Integer pageSize
            ){
        if(StringUtils.isBlank(itemId)) {
            return IMOOCJSONResult.errorMsg(null);
        }
        if (page == null){
            page = 1;
        }
        if (pageSize == null){
            pageSize = COMMENT_PAGE_SIZE;
        }
        PagedGridResult result = itemService.queryPagedComments(itemId,level,page,pageSize);

        return IMOOCJSONResult.ok(result);
    }
    @ApiOperation(value = "搜索商品列表", notes = "搜索商品列表", httpMethod = "GET")
    @GetMapping("/search")
    public IMOOCJSONResult search(
            @ApiParam(name = "keywords",value = "搜索关键字",required = true)
            @RequestParam String keywords,
            @ApiParam(name = "sort",value = "按什么字段排序",required = false)
            @RequestParam String sort,
            @ApiParam(name = "page",value = "查询下一页的第几页",required = false)
            @RequestParam Integer page,
            @ApiParam(name = "pageSize",value = "分页的每一页显示的条数",required = false)
            @RequestParam Integer pageSize
    ){
        if(StringUtils.isBlank(keywords)) {
            return IMOOCJSONResult.errorMsg(null);
        }
        if (page == null){
            page = 1;
        }
        if (pageSize == null){
            pageSize = PAGE_SIZE;
        }
        PagedGridResult result = itemService.searchItems(keywords,sort,page,pageSize);

        return IMOOCJSONResult.ok(result);
    }

    @ApiOperation(value = "根据商品分类id搜索商品列表", notes = "根据商品分类id搜索商品列表", httpMethod = "GET")
    @GetMapping("/catItems")
    public IMOOCJSONResult catItems(
            @ApiParam(name = "catId",value = "分类id",required = true)
            @RequestParam Integer catId,
            @ApiParam(name = "sort",value = "按什么字段排序",required = false)
            @RequestParam String sort,
            @ApiParam(name = "page",value = "查询下一页的第几页",required = false)
            @RequestParam Integer page,
            @ApiParam(name = "pageSize",value = "分页的每一页显示的条数",required = false)
            @RequestParam Integer pageSize
    ){
        if(catId == null) {
            return IMOOCJSONResult.errorMsg(null);
        }
        if (page == null){
            page = 1;
        }
        if (pageSize == null){
            pageSize = PAGE_SIZE;
        }
        PagedGridResult result = itemService.searchItemsByThirdCat(catId,sort,page,pageSize);

        return IMOOCJSONResult.ok(result);
    }
//    @ApiOperation(value = "刷新购物车信息", notes = "刷新购物车信息", httpMethod = "GET")
//    @GetMapping("/refresh")
//    public IMOOCJSONResult refresh(
//            @ApiParam(name = "itemSpecIds",value = "分类id",required = true)
//            @RequestParam String itemSpecIds,
//            @ApiParam(name = "page",value = "查询下一页的第几页",required = false)
//            @RequestParam Integer page,
//            @ApiParam(name = "pageSize",value = "分页的每一页显示的条数",required = false)
//            @RequestParam Integer pageSize
//    ){
//        if(itemSpecIds == null && "".equals(itemSpecIds)) {
//            return IMOOCJSONResult.errorMsg(null);
//        }
//        if (page == null){
//            page = 1;
//        }
//        if (pageSize == null){
//            pageSize = PAGE_SIZE;
//        }
//        PagedGridResult result = itemService.searchItemsByThirdCat(catId,sort,page,pageSize);

//        return IMOOCJSONResult.ok();
//    }

    //用于用户长时间未登录网站，刷新购物车中的数据（主要是商品价格），类似京东淘宝
    @ApiOperation(value = "根据商品规格ids查询最新的商品数据", notes = "根据商品规格ids查询最新的商品数据", httpMethod = "GET")
    @GetMapping("/refresh")
    public IMOOCJSONResult refresh(
            @ApiParam(name = "itemSpecIds",value = "拼接的规格ids",required = true,example = "1001,1003,1005")
            @RequestParam String itemSpecIds
    ){
        if(itemSpecIds == null && itemSpecIds.equals("")) {
            return IMOOCJSONResult.ok();
        }
//        PagedGridResult result = itemService.searchItemsByThirdCat(catId,sort,page,pageSize);
        List<ShopcartVO> list = itemService.queryItemsBySpecIds(itemSpecIds);
        return IMOOCJSONResult.ok(list);
    }
}
