package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.ItemsImg;

public interface ItemsImgMapper extends MyMapper<ItemsImg> {
}