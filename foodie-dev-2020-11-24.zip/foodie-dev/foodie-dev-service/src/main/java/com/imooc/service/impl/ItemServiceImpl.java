package com.imooc.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.imooc.enums.CommentLevel;
import com.imooc.mapper.*;
import com.imooc.pojo.*;
import com.imooc.pojo.vo.CommentLevelCountsVO;
import com.imooc.pojo.vo.ItemCommentVO;
import com.imooc.pojo.vo.SearchItemsVO;
import com.imooc.pojo.vo.ShopcartVO;
import com.imooc.service.CarouselService;
import com.imooc.service.ItemService;
import com.imooc.utils.DesensitizationUtil;
import com.imooc.utils.PagedGridResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.*;

@Service
public class ItemServiceImpl implements ItemService {

    @Autowired
    private ItemsMapper itemsMapper;

    @Autowired
    private ItemsImgMapper itemsImgMapper;
    @Autowired
    private ItemsParamMapper itemsParamMapper;
    @Autowired
    private ItemsSpecMapper itemsSpecMapper;
    @Autowired
    private ItemsCommentsMapper itemsCommentsMapper;
    @Autowired
    private ItemsMapperCustom itemsMapperCustom;

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public Items queryItemById(String itemId) {
//        Example example = new Example(Items.class);
//        Example.Criteria criteria = example.createCriteria();
//        criteria.andEqualTo("id",itemId);
        Items items = itemsMapper.selectByPrimaryKey(itemId);
        return items;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<ItemsImg> queryItemImgList(String itemId) {
        Example example = new Example(ItemsImg.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("itemId",itemId);
        List<ItemsImg> itemsImgList = itemsImgMapper.selectByExample(example);
        return itemsImgList;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<ItemsSpec> queryItemSpecList(String itemId) {
        Example example = new Example(ItemsSpec.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("itemId",itemId);
        List<ItemsSpec> itemsSpecList = itemsSpecMapper.selectByExample(example);
        return itemsSpecList;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public ItemsParam queryItemParam(String itemId) {
        Example example = new Example(ItemsParam.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("itemId",itemId);
        ItemsParam itemsParam = itemsParamMapper.selectOneByExample(example);
        return itemsParam;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public CommentLevelCountsVO queryCommentCounts(String ItemId) {

        Integer goodCount = getCommentCounts(ItemId,CommentLevel.GOOD.type);
        Integer normalCounts = getCommentCounts(ItemId,CommentLevel.NORMAL.type);
        Integer badCounts = getCommentCounts(ItemId,CommentLevel.BAD.type);
        Integer totalCount = goodCount+normalCounts+badCounts;

        CommentLevelCountsVO commentLevelCountsVO =new CommentLevelCountsVO();
        commentLevelCountsVO.setGoodCounts(goodCount);
        commentLevelCountsVO.setBadCounts(badCounts);
        commentLevelCountsVO.setNormalCounts(normalCounts);
        commentLevelCountsVO.setTotalCounts(totalCount);

        return commentLevelCountsVO;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult queryPagedComments(String itemId, Integer level,Integer page,Integer pageSize) {
        Map<String , Object> map = new HashMap<>();
        map.put("itemId",itemId);
        map.put("level",level);
        //mybatis-pagehelper插件 统一的分页插件
        /**
         * page:第几页
         * pageSize:每页显示条数
         */
        PageHelper.startPage(page,pageSize);

        List<ItemCommentVO> itemCommentVOS = itemsMapperCustom.queryItemComments(map);
        for (ItemCommentVO vo:itemCommentVOS){
            vo.setNickname(DesensitizationUtil.commonDisplay(vo.getNickname()));
        }
        PagedGridResult result = setterPagedGrid(itemCommentVOS,page);
        return result;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult searchItems(String keywords, String sort, Integer page, Integer pageSize) {
        Map<String , Object> map = new HashMap<>();
        map.put("keywords",keywords);
        map.put("sort",sort);
        /**
         * page:第几页
         * pageSize:每页显示条数
         */
        PageHelper.startPage(page,pageSize);

        List<SearchItemsVO> searchItemsVOS = itemsMapperCustom.searchItems(map);

        PagedGridResult result = setterPagedGrid(searchItemsVOS,page);
        return result;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult searchItemsByThirdCat(Integer catId, String sort, Integer page, Integer pageSize) {
        Map<String , Object> map = new HashMap<>();
        map.put("catId",catId);
        map.put("sort",sort);
        /**
         * page:第几页
         * pageSize:每页显示条数
         */
        PageHelper.startPage(page,pageSize);

        List<SearchItemsVO> searchItemsVOS = itemsMapperCustom.searchItemsByThirdCat(map);

        PagedGridResult result = setterPagedGrid(searchItemsVOS,page);
        return result;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<ShopcartVO> queryItemsBySpecIds(String specIds) {
        String ids[] = specIds.split(",");
        List<String> specIdList = new ArrayList<>();

        for (String  specId:ids) {
            specIdList.add(specId);
        }
//        Collections.addAll(specIdList,ids);
        List<ShopcartVO> result = itemsMapperCustom.queryItemsBySpecIds(specIdList);
        return result;
    }

    @Transactional(propagation = Propagation.SUPPORTS)
    public Integer getCommentCounts(String itemId, Integer level){

        ItemsComments condition = new ItemsComments();
        condition.setItemId(itemId);
        if (level !=null) {
            condition.setCommentLevel(level);
        }
        Integer count = itemsCommentsMapper.selectCount(condition);
        return count;
    }

    private PagedGridResult setterPagedGrid(List<?> list,Integer page){
        PageInfo<?> pageList = new PageInfo<>(list);
        PagedGridResult result = new PagedGridResult();
        result.setPage(page);
        //数据总条数
        result.setRecords(pageList.getTotal());
        //数据总页数
        result.setTotal(pageList.getPages());
        result.setRows(list);
        return result;
    }
}
