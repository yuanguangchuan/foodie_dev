package com.imooc.service;

import com.imooc.pojo.UserAddress;
import com.imooc.pojo.bo.AddressBO;

import java.util.List;

public interface AddressService {

    /**
     * 查询用户的所有收货地址列表
     * @return
     */
    public List<UserAddress> queryAllUserAddress(String userId);

/**
     * 添加用户收货地址
     * @param addressBO
     * @return
     */
    public UserAddress insertUserAddress(AddressBO addressBO);

    /**
     * 根据用户id和地址id删除用户的收货地址信息
     * @param userId
     * @param addressId
     * @return
     */
    public Integer delUserAddressById(String userId,String addressId);

    /**
     * 修改用户收货地址
     * @param addressBO
     * @return
     */
    public UserAddress updateUserAddress(AddressBO addressBO);
    /**
     * 修改默认地址
     * @param userId
     * @param addressId
     */
    public void updateUserAddressToBeDefault(String userId, String addressId);
    /**
     * 根据用户id和地址id，查询具体的用户地址对象信息
     * @param userId
     * @param addressId
     * @return
     */
    public UserAddress queryUserAddress(String userId, String addressId);
}
