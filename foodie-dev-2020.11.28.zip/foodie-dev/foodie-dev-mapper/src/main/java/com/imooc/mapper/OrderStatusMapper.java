package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.OrderStatus;

public interface OrderStatusMapper extends MyMapper<OrderStatus> {
}