package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.Items;

public interface ItemsMapper extends MyMapper<Items> {
}