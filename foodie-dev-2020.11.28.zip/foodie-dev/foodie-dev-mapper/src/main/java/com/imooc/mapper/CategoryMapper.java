package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.Category;

public interface CategoryMapper extends MyMapper<Category> {
}