package com.imooc.service;

import com.imooc.pojo.Carousel;
import com.imooc.pojo.OrderStatus;
import com.imooc.pojo.bo.SubmitOrderBO;

import java.util.List;

//轮播图
public interface OrderService {

    /**
     * 用于创建订单信息
     * @param submitOrderBO
     */
    public void createOrder(SubmitOrderBO submitOrderBO);

    /**
     * 查询订单状态
     * @param orderId
     * @return
     */
    public OrderStatus queryOrderStatusInfo(String orderId);
    /**
     * 修改订单状态
     * @param orderId
     * @param orderStatus
     */
    public void updateOrderStatus(String orderId, Integer orderStatus);
    /**
     * 关闭超时未支付订单
     */
    public void closeOrder();
}
