package com.imooc.controller;

import org.springframework.stereotype.Controller;

/**
 * controller公共参数
 */
@Controller
public class BaseController {

    public static final Integer COMMENT_PAGE_SIZE = 10;
    public static final Integer PAGE_SIZE = 20;
}
