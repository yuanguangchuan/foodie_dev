package com.imooc.controller;

import com.imooc.enums.OrderStatusEnum;
import com.imooc.enums.PayMethod;
import com.imooc.pojo.*;
import com.imooc.pojo.bo.SubmitOrderBO;
import com.imooc.pojo.vo.ItemInfoVO;
import com.imooc.service.OrderService;
import com.imooc.utils.IMOOCJSONResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * controller公共参数
 */
@Api(value = "订单相关",tags = {"订单相关的相关接口"})
@RequestMapping("orders")
@RestController
public class OrdersController {

    @Autowired
    private OrderService orderService;
    @ApiOperation(value = "用户下单", notes = "用户下单", httpMethod = "POST")
    @PostMapping("/create")
    public IMOOCJSONResult create(
            @ApiParam(name = "submitOrderBO",value = "订单数据",required = true)
            @PathVariable SubmitOrderBO submitOrderBO){

        if (submitOrderBO.getPayMethod() != PayMethod.WEIXIN.type&&
                submitOrderBO.getPayMethod() != PayMethod.ALIPAY.type){

            IMOOCJSONResult.errorMsg("支付方式不支持!");
        }
        //1.创建订单
        //2.创建订单以后，移除购物车已结算（已提交）的商品
        //3.向支付中心发送当前订单，用于保存支付中心的订单数据


        return IMOOCJSONResult.ok();
    }

    @ApiOperation(value = "支付页面获取订单状态", notes = "支付页面获取订单状态", httpMethod = "GET")
    @GetMapping("/getPaidOrderInfo")
    public IMOOCJSONResult getPaidOrderInfo(
            @ApiParam(name = "orderId",value = "订单id",required = true)
            @PathVariable String orderId){
        OrderStatus orderStatus = orderService.queryOrderStatusInfo(orderId);


        return IMOOCJSONResult.ok(orderStatus);
    }

//    @ApiOperation(value = "获取微信支付二维码", notes = "获取微信支付二维码", httpMethod = "GET")
//    @GetMapping("/getWXPayQRCode")
//    public IMOOCJSONResult getWXPayQRCode(
//            @ApiParam(name = "merchantUserId",value = "商户id",required = true)
//            @PathVariable String merchantUserId,
//            @ApiParam(name = "merchantOrderId",value = "订单id",required = true)
//            @PathVariable String merchantOrderId){
//        if (merchantUserId.equals("")||merchantUserId==null){
//            IMOOCJSONResult.errorMsg("商户id不能为空");
//        }
//        if (merchantOrderId.equals("")||merchantOrderId==null){
//            IMOOCJSONResult.errorMsg("用户id不能为空");
//        }
//
//
//        return IMOOCJSONResult.ok();
//    }

    @PostMapping("notifyMerchantOrderPaid")
    public Integer notifyMerchantOrderPaid(String merchantOrderId) {
        orderService.updateOrderStatus(merchantOrderId, OrderStatusEnum.WAIT_DELIVER.type);
        return HttpStatus.OK.value();
    }
}
