package com.imooc.pojo.vo;

import java.util.List;

/**
 *
 */
public class NewItemsVO {

    private Integer rootCatId;
    private String  rootName;
    private String  slogan;
    private String  catImage;
    private String  bgColor;
    private List<SimpleItemVO> simpleItemVOList;

    public Integer getRootCatId() {
        return rootCatId;
    }

    public void setRootCatId(Integer rootCatId) {
        this.rootCatId = rootCatId;
    }

    public String getRootName() {
        return rootName;
    }

    public void setRootName(String rootName) {
        this.rootName = rootName;
    }

    public String getSlogan() {
        return slogan;
    }

    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    public String getCatImage() {
        return catImage;
    }

    public void setCatImage(String catImage) {
        this.catImage = catImage;
    }

    public String getBgColor() {
        return bgColor;
    }

    public void setBgColor(String bgColor) {
        this.bgColor = bgColor;
    }

    public List<SimpleItemVO> getSimpleItemVOList() {
        return simpleItemVOList;
    }

    public void setSimpleItemVOList(List<SimpleItemVO> simpleItemVOList) {
        this.simpleItemVOList = simpleItemVOList;
    }
}
