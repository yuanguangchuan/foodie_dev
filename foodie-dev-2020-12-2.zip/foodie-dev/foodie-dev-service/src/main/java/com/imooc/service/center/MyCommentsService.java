package com.imooc.service.center;

import com.imooc.pojo.OrderItems;
import com.imooc.pojo.bo.center.OrderItemsCommentBO;

import java.util.List;

public interface MyCommentsService {

    /**
     * 根据订单id查询订单相关商品列表
     * @param orderId
     * @return
     */
    public List<OrderItems> queryPendingComment(String orderId);

    /**
     * 根据用户id查询所有未评价订单商品
     * @param userId
     * @return
     */
    public List<OrderItems> queryAllItemCommentByUserId(String userId);

    /**
     * 保存用户订单评价信息
     * @param userId
     * @param orderId
     * @param orderItemsCommentBOS
     */
    public void saveComment(String userId, String orderId,
                            List<OrderItemsCommentBO> orderItemsCommentBOS);
}
