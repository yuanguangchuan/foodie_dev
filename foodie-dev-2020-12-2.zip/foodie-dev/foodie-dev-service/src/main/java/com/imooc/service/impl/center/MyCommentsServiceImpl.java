package com.imooc.service.impl.center;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.imooc.enums.OrderStatusEnum;
import com.imooc.enums.YesOrNo;
import com.imooc.mapper.*;
import com.imooc.pojo.ItemsComments;
import com.imooc.pojo.OrderItems;
import com.imooc.pojo.OrderStatus;
import com.imooc.pojo.Orders;
import com.imooc.pojo.bo.center.OrderItemsCommentBO;
import com.imooc.pojo.vo.MyOrdersVO;
import com.imooc.service.OrderService;
import com.imooc.service.center.MyCommentsService;
import com.imooc.service.center.MyOrdersService;
import com.imooc.utils.PagedGridResult;
import org.aspectj.weaver.ast.Or;
import org.n3r.idworker.Sid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class MyCommentsServiceImpl implements MyCommentsService {

    @Autowired
    private OrderItemsMapper orderItemsMapper;
    @Autowired
    private OrderStatusMapper orderStatusMapper;
    @Autowired
    private OrderService orderService;
    @Autowired
    private Sid sid;

    @Autowired
    private ItemsCommentsMapperCustom itemsCommentsMapperCustom;
    @Autowired
    private ItemsCommentsMapper itemsCommentsMapper;
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<OrderItems> queryPendingComment(String orderId) {
        OrderItems query = new OrderItems();
        query.setOrderId(orderId);
        List<OrderItems> resultList= orderItemsMapper.select(query);
        return resultList;
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public List<OrderItems> queryAllItemCommentByUserId(String userId) {
        return null;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void saveComment(String userId, String orderId,
                            List<OrderItemsCommentBO> orderItemsCommentBOS) {
        ItemsComments itemsComments = new ItemsComments();
        //1.保存评价 items_comments
        for (OrderItemsCommentBO oic:orderItemsCommentBOS){
            itemsComments.setId(sid.nextShort());
            itemsComments.setItemId(oic.getItemId());
            itemsComments.setItemName(oic.getItemName());
            itemsComments.setCommentLevel(oic.getCommentLevel());
            itemsComments.setContent(oic.getContent());
            itemsComments.setCreatedTime(new Date());
            itemsComments.setUpdatedTime(new Date());
            itemsComments.setItemSpecId(oic.getItemSpecId());
            itemsComments.setSepcName(oic.getItemSpecName());
            itemsComments.setUserId(userId);
            itemsCommentsMapper.insert(itemsComments);
        }
//        //1.保存评价 items_comments
//        for (OrderItemsCommentBO oic:orderItemsCommentBOS){
//            oic.setCommentId(sid.nextShort());
//        }
//        Map<String , Object> map = new HashMap<>();
//        map.put("userId",userId);
//        map.put("commentList",orderItemsCommentBOS);
//        itemsCommentsMapperCustom.saveItemsComment(map);
        //2.修改订单表已改评价 orders
        orderService.updateOrderCommentStatus(userId,orderId);
        //3.修改订单状态表的状态  order_status
        OrderStatus orderStatus  = new OrderStatus();
        orderStatus.setOrderId(orderId);
        orderStatus.setCommentTime(new Date());
        orderStatusMapper.updateByPrimaryKeySelective(orderStatus);
    }
}
