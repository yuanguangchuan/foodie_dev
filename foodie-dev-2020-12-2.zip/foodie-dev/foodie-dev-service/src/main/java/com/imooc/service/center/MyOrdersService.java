package com.imooc.service.center;

import com.imooc.pojo.Orders;
import com.imooc.pojo.Users;
import com.imooc.pojo.bo.center.CenterUserBO;
import com.imooc.pojo.vo.MyOrdersVO;
import com.imooc.utils.PagedGridResult;

import java.util.List;

public interface MyOrdersService {

    /**
     * 查询我的订单列表
     * @param userId
     * @param orderStatus
     * @param page
     * @param pageSize
     * @return
     */
    public PagedGridResult queryOrderMessage(String userId ,
                                             Integer orderStatus,
                                             Integer page,
                                             Integer pageSize);
    /**
     * 修改订单状态->商家发货
     * @param orderId
     * @return
     */
    public void updateDeliverOrderStatus(String orderId);

    /**
     * 校验用户和订单是否捆绑在一起
     * @param userId
     * @param orderId
     * @return
     */
    public Orders isTogetherBetweenUserAndOrder(String userId, String orderId);

    /**
     * 用户确认收货
     *
     * @param orderId
     */
    public Boolean confirmReceive(String orderId);

    /**
     * 用户逻辑删除该订单
     *
     * @param orderId
     * @param userId
     */
    public Boolean deleteOrder(String orderId,String userId);
}
