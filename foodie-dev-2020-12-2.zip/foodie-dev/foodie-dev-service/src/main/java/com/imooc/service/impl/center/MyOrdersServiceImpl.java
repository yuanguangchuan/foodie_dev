package com.imooc.service.impl.center;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.imooc.enums.OrderStatusEnum;
import com.imooc.enums.YesOrNo;
import com.imooc.mapper.OrderStatusMapper;
import com.imooc.mapper.OrdersMapper;
import com.imooc.mapper.OrdersMapperCustom;
import com.imooc.mapper.UsersMapper;
import com.imooc.pojo.OrderStatus;
import com.imooc.pojo.Orders;
import com.imooc.pojo.Users;
import com.imooc.pojo.bo.center.CenterUserBO;
import com.imooc.pojo.vo.MyOrdersVO;
import com.imooc.service.center.CenterUserSrvice;
import com.imooc.service.center.MyOrdersService;
import com.imooc.utils.PagedGridResult;
import org.n3r.idworker.Sid;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import tk.mybatis.mapper.entity.Example;

import java.util.*;

@Service
public class MyOrdersServiceImpl implements MyOrdersService {

    @Autowired
    private OrderStatusMapper orderStatusMapper;
    @Autowired
    private OrdersMapper ordersMapper;
    @Autowired
    private OrdersMapperCustom ordersMapperCustom;
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public PagedGridResult queryOrderMessage(String userId ,
                                             Integer orderStatus,
                                             Integer page,
                                             Integer pageSize) {
        Map<String ,Object> map = new HashMap<>();
        map.put("userId",userId);
        if (orderStatus!= null){
            map.put("orderStatus",orderStatus);
        }
        PageHelper.startPage(page,pageSize);

        List<MyOrdersVO> resultList = ordersMapperCustom.queryOrderMessage(map);

        PagedGridResult result = setterPagedGrid(resultList,page);
        return result;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void updateDeliverOrderStatus(String orderId) {
        OrderStatus updateOrder = new OrderStatus();
        updateOrder.setOrderStatus(OrderStatusEnum.WAIT_RECEIVE.type);
        updateOrder.setDeliverTime(new Date());

        Example example = new Example(OrderStatus.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("orderId",orderId);
        criteria.andEqualTo("orderStatus",OrderStatusEnum.WAIT_DELIVER.type);
        orderStatusMapper.updateByExampleSelective(updateOrder,example);
    }
    @Transactional(propagation = Propagation.SUPPORTS)
    @Override
    public Orders isTogetherBetweenUserAndOrder(String userId, String orderId) {

        Example example = new Example(Orders.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("userId",userId);
        criteria.andEqualTo("id",orderId);
        criteria.andEqualTo("isDelete", YesOrNo.NO.type);
        Orders orders= ordersMapper.selectOneByExample(example);


        return orders;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Boolean confirmReceive( String orderId) {
        OrderStatus updateOrder = new OrderStatus();
        updateOrder.setOrderStatus(OrderStatusEnum.SUCCESS.type);
        updateOrder.setSuccessTime(new Date());

        Example example = new Example(OrderStatus.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("orderId",orderId);
        criteria.andEqualTo("orderStatus",OrderStatusEnum.WAIT_RECEIVE.type);
        Integer isfoodie = orderStatusMapper.updateByExampleSelective(updateOrder,example);
        return isfoodie==0?false:true;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Boolean deleteOrder( String orderId,String userId) {
        Orders updateOrder = new Orders();
//todo 删除订单;待做 校验删除订单时状态是否符合
        updateOrder.setUpdatedTime(new Date());
        updateOrder.setIsDelete(YesOrNo.YES.type);

        Example example = new Example(Orders.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("id",orderId);
        criteria.andEqualTo("userId",userId);
        Integer isfoodie = ordersMapper.updateByExampleSelective(updateOrder,example);
        return isfoodie==0?false:true;
    }

    private PagedGridResult setterPagedGrid(List<?> list,Integer page){
        PageInfo<?> pageList = new PageInfo<>(list);
        PagedGridResult result = new PagedGridResult();
        result.setPage(page);
        //数据总条数
        result.setRecords(pageList.getTotal());
        //数据总页数
        result.setTotal(pageList.getPages());
        result.setRows(list);
        return result;
    }
}
