package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.Orders;
import com.imooc.pojo.vo.MyOrdersVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface OrdersMapperCustom {

    /**
     *  根据用户id和订单状态查询用户订单信息
     * @param map
     * @return
     */
    public List<MyOrdersVO> queryOrderMessage(@Param("paramsMap") Map<String, Object> map);

    public List<MyOrdersVO> queryOrderMessageDoNotUse(@Param("paramsMap") Map<String, Object> map);

    public Integer deleteOrder(@Param("paramsMap") Map<String, Object> map);
}