package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.ItemsParam;

public interface ItemsParamMapper extends MyMapper<ItemsParam> {
}