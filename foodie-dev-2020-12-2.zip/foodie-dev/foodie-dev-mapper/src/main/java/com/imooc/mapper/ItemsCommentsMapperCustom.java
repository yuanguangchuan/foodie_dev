package com.imooc.mapper;

import com.imooc.my.mapper.MyMapper;
import com.imooc.pojo.ItemsComments;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.Map;

@Mapper
public interface ItemsCommentsMapperCustom extends MyMapper<ItemsComments> {
    /**
     * 保存订单评价列表
     * @param map
     */
    public void saveItemsComment(Map<String, Object> map);
}