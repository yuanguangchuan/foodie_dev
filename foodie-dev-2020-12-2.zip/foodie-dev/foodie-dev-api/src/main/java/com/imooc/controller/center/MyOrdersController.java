package com.imooc.controller.center;

import com.imooc.controller.BaseController;
import com.imooc.pojo.Orders;
import com.imooc.service.center.MyOrdersService;
import com.imooc.utils.IMOOCJSONResult;
import com.imooc.utils.PagedGridResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Api(value = "我的订单详情页",tags = {"我的订单详情页相关接口"})
@RestController
@RequestMapping("myorders")
public class MyOrdersController extends BaseController {

    @Autowired
    private MyOrdersService myOrdersService;

    @ApiOperation(value = "查询我的所有订单信息",notes = "查询我的所有订单信息",httpMethod = "POST")
    @PostMapping("query")
    public IMOOCJSONResult query(
            @ApiParam(value = "userId",name = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(value = "orderStatus",name = "订单状态",required = true)
            @RequestParam Integer orderStatus,
            @ApiParam(name = "page",value = "查询下一页的第几页",required = false)
            @RequestParam Integer page,
            @ApiParam(name = "pageSize",value = "分页的每一页显示的条数",required = false)
            @RequestParam Integer pageSize){
        if (page==null){
            page = COMMENT_PAGE_SIZE;
        }
        if (pageSize == null){
            pageSize = PAGE_SIZE;
        }
        PagedGridResult result = myOrdersService.queryOrderMessage(userId,orderStatus,page,pageSize);
        return IMOOCJSONResult.ok(result);
    }
    //上架发货后没有后端 ， 所以这个接口模拟商户发货
    @ApiOperation(value = "商家发货",notes = "商家发货",httpMethod = "GET")
    @GetMapping("daliver")
    public IMOOCJSONResult daliver(
            @ApiParam(value = "orderId",name = "订单id",required = true)
            @RequestParam String orderId
            ){
        if (orderId==null){
            IMOOCJSONResult.errorMsg("订单号不能为空");
        }
        myOrdersService.updateDeliverOrderStatus(orderId);
        return IMOOCJSONResult.ok();
    }

    @ApiOperation(value = "用户确认收货",notes = "用户确认收货",httpMethod = "POST")
    @PostMapping("confirmReceive")
    public IMOOCJSONResult confirmReceive(
            @ApiParam(value = "userId",name = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(value = "orderId",name = "订单id",required = true)
            @RequestParam String orderId
    ){
        if (userId==null){
            return IMOOCJSONResult.errorMsg("用户编号不能为空");
        }
        if (orderId==null){
            return IMOOCJSONResult.errorMsg("订单号不能为空");
        }
        Orders orders = myOrdersService.isTogetherBetweenUserAndOrder(userId,orderId);
        if (orders==null){
            return IMOOCJSONResult.errorMsg("当前订单不属于该用户");
        }

        if (!myOrdersService.confirmReceive(orderId)){
            return IMOOCJSONResult.errorMsg("修改失败");
        }
        return IMOOCJSONResult.ok();
    }

    @ApiOperation(value = "用户删除订单",notes = "用户删除订单",httpMethod = "POST")
    @PostMapping("delete")
    public IMOOCJSONResult delete(
            @ApiParam(value = "userId",name = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(value = "orderId",name = "订单id",required = true)
            @RequestParam String orderId
    ){
        if (userId==null){
            return IMOOCJSONResult.errorMsg("用户编号不能为空");
        }
        if (orderId==null){
            return IMOOCJSONResult.errorMsg("订单号不能为空");
        }
        Orders orders = myOrdersService.isTogetherBetweenUserAndOrder(userId,orderId);
        if (orders==null){
            return IMOOCJSONResult.errorMsg("当前订单不属于该用户");
        }
        if (!myOrdersService.deleteOrder(orderId,userId))
        {
            return IMOOCJSONResult.errorMsg("删除失败");
        }
        return IMOOCJSONResult.ok();
    }
}
