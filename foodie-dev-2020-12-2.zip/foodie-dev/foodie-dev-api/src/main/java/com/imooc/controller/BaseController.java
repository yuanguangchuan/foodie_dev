package com.imooc.controller;

import org.springframework.stereotype.Controller;

import java.io.File;

/**
 * controller公共参数
 */
@Controller
public class BaseController {

    public static final String FOODIE_SHOPCART = "shopcart";

    public static final Integer COMMENT_PAGE_SIZE = 10;
    public static final Integer PAGE_SIZE = 20;

    //用户上传头像的位置 File.separator分隔符(/)
    public static final String IMG_USER_FACE_LOCATION = File.separator+"workspaces"
                                                        +File.separator+"images"
                                                        +File.separator+"foodie"
                                                        +File.separator+"faces";
//    public static final String IMG_USER_FACE_LOCATION = "\workspaces\images\foodie\faces";
}
