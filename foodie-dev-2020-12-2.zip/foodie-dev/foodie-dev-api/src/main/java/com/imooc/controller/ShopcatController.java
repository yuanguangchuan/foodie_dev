package com.imooc.controller;

import com.imooc.enums.YesOrNo;
import com.imooc.pojo.Carousel;
import com.imooc.pojo.Category;
import com.imooc.pojo.bo.ShopcartBO;
import com.imooc.pojo.vo.CategoryVO;
import com.imooc.pojo.vo.NewItemsVO;
import com.imooc.service.CarouselService;
import com.imooc.service.CategoryService;
import com.imooc.utils.IMOOCJSONResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.logging.stdout.StdOutImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;

@Api(value = "购物车",tags = {"购物车相关接口"})
@RestController
@RequestMapping("shopcart")
public class ShopcatController {


    @ApiOperation(value = "添加商品购物车到后端", notes = "添加商品购物车到后端", httpMethod = "POST")
    @PostMapping("add")
    public IMOOCJSONResult add(
            @ApiParam(name = "userId",value = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(name = "shopcartBO",value = "商品购物车信息",required = true)
            @RequestBody ShopcartBO shopcartBO,
            HttpServletResponse response,
            HttpServletRequest request){

        if (StringUtils.isBlank(userId)){
            return  IMOOCJSONResult.errorMsg("");
        }
        // TODO 前段用户在登录的情况下，添加商品到购物车，会同同时在后端同步购物车到redis缓存
        System.out.println(shopcartBO.toString());
        return IMOOCJSONResult.ok();
    }

    @ApiOperation(value = "从购物车中删除商品", notes = "从购物车中删除商品", httpMethod = "POST")
    @PostMapping("del")
    public IMOOCJSONResult del(
            @ApiParam(name = "userId",value = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(name = "itemSpecId",value = "商品规格id",required = true)
            @RequestParam String itemSpecId,
            HttpServletResponse response,
            HttpServletRequest request){

        if (StringUtils.isBlank(userId)||StringUtils.isBlank(itemSpecId)){
            return  IMOOCJSONResult.errorMsg("参数不能为空");
        }
        // TODO 用户在页面删除购物车中的商品数据，如果此时用户已经登录，则需要同步删除后端购物车数据

        return IMOOCJSONResult.ok();
    }

}
