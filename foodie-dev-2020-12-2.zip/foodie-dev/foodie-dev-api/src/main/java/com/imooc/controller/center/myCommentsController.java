package com.imooc.controller.center;

import com.imooc.controller.BaseController;
import com.imooc.enums.YesOrNo;
import com.imooc.pojo.OrderItems;
import com.imooc.pojo.Orders;
import com.imooc.pojo.bo.center.OrderItemsCommentBO;
import com.imooc.service.center.MyCommentsService;
import com.imooc.service.center.MyOrdersService;
import com.imooc.utils.IMOOCJSONResult;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Api(value = "评论管理" ,tags = {"评论管理相关api"})
@RestController
@RequestMapping("mycomments")
public class myCommentsController extends BaseController {

    @Autowired
    private MyOrdersService myOrdersService;

    @Autowired
    private MyCommentsService myCommentsService;

    @ApiOperation(value = "查询我的所有评论信息",notes = "查询我的所有评论信息",httpMethod = "POST")
    @PostMapping("query")
    public IMOOCJSONResult query(
            @ApiParam(value = "userId",name = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(name = "page",value = "查询下一页的第几页",required = false)
            @RequestParam Integer page,
            @ApiParam(name = "pageSize",value = "分页的每一页显示的条数",required = false)
            @RequestParam Integer pageSize){
        if (page==null){
            page = COMMENT_PAGE_SIZE;
        }
        if (pageSize == null){
            pageSize = PAGE_SIZE;
        }


        return IMOOCJSONResult.ok();
    }

    @ApiOperation(value = "查询当前订单的所有商品信息",notes = "查询当前订单的所有商品信息",httpMethod = "POST")
    @PostMapping("pending")
    public IMOOCJSONResult pending(
            @ApiParam(value = "userId",name = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(value = "orderId",name = "订单id",required = true)
            @RequestParam String orderId
            ){

        Orders orders = myOrdersService.isTogetherBetweenUserAndOrder(userId,orderId);
        if (orders==null){
            return IMOOCJSONResult.errorMsg("当前订单不属于该用户");
        }
        if (orders.getIsComment()== YesOrNo.YES.type){
            return IMOOCJSONResult.errorMsg("该笔订单已经评价");
        }

        List<OrderItems> result= myCommentsService.queryPendingComment(orderId);
        return IMOOCJSONResult.ok(result);
    }

    @ApiOperation(value = "保存订单评论信息列表",notes = "保存订单评论信息列表",httpMethod = "POST")
    @PostMapping("saveList")
    public IMOOCJSONResult saveList(
            @ApiParam(value = "userId",name = "用户id",required = true)
            @RequestParam String userId,
            @ApiParam(value = "orderId",name = "订单id",required = true)
            @RequestParam String orderId,
            @ApiParam(value = "commentList",name = "评论列表",required = true)
            @RequestBody List<OrderItemsCommentBO> commentList
    ){

        if (commentList==null||commentList.isEmpty()||commentList.size()==0){
            IMOOCJSONResult.errorMsg("评论内容不能为空");
        }
        Orders orders = myOrdersService.isTogetherBetweenUserAndOrder(userId,orderId);
        if (orders==null){
            return IMOOCJSONResult.errorMsg("当前订单不属于该用户");
        }
        if (orders.getIsComment()==1){
            return IMOOCJSONResult.errorMsg("该笔订单已经评价");
        }
//        System.out.println(commentList.toString());

        myCommentsService.saveComment(userId,orderId,commentList);
        return IMOOCJSONResult.ok();

    }
}
